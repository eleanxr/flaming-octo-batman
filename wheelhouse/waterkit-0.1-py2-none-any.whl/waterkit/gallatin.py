
USGS_SITES = [
    "06043500",
    #"06044000",
    "06045000",
    "06045500",
    "06052500"
]

USGS_SITE_NAMES = [
    "Gallatin Gateway",
    #"Salesville",
    "Axtell Bridge",
    "Belgrade",
    "Logan"
]
